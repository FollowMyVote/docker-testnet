#!/bin/bash

noWork() {
   echo "Nothing to do."
   exit 100
}
[ -e InitChain.script ] || noWork

i=0
until /var/fmv/local/bin/cli_wallet < /dev/null
do
    if [ $i -gt 4 ]
    then
        echo "Node isn't up yet... Giving up."
        exit 1
    fi
    echo "Node isn't up yet... Waiting..."
    sleep 3
    let i+=1
done

echo "Running InitChain.script"
cat InitChain.script | /var/fmv/local/bin/cli_wallet && rm InitChain.script
